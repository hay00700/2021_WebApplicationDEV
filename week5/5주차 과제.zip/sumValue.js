function sumValue(){
	let a = document.getElementById("v1").value;
	let b = document.getElementById("v2").value;
	document.getElementById("v3").innerHTML = Number(a) + Number(b);
}